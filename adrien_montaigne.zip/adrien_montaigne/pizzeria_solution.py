# Adrien Montaigne

import numpy as np
  
  


# Enter the size of the city N and the number of pizzerias M
pizzeria=[]
N, M = input().split()
N = int(N)
M = int(M)

#creation of the city
city = np.empty((N, N))
for i in range (0,N):
    for j in range (0,N):
        city [i][j] = 0


for i in range(0,M): 
    list=[]
    x, y, R = input().split()
    x = int(x)
    y = int(y)
    R = int(R)
    list.append(x)
    list.append(y)
    list.append(R)
    pizzeria.append(list)



# pizzeria[u][0] is the x coordinates of the pizzeria
# pizzeria[u][1] is the y coordinates of the pizzeria
# pizzeria[u][2] is the maximum delivery distance



for u in range(0,M):
    for i in range (0, pizzeria[u][2] + 1):
        if (i == 0):
            if  (- pizzeria[u][2] + pizzeria[u][0] >= 1 and - pizzeria[u][2] + pizzeria[u][0]<= N
            and pizzeria[u][1]>= 0 and pizzeria[u][1] <= N -1) :
                city[- pizzeria[u][2] + pizzeria[u][0] - 1][pizzeria[u][1] - 1] += 1
        else:   

            for j in range (-i, i + 1):
                if  (- pizzeria[u][2] + pizzeria[u][0] + i >= 1 and - pizzeria[u][2] + pizzeria[u][0] + i <= N - 1
                    and pizzeria[u][1] + j - 1 >= 0 and pizzeria[u][1] + j - 1 <= N - 1):
                    city[- pizzeria[u][2] + pizzeria[u][0] + i - 1][pizzeria[u][1] + j - 1] += 1

    for i in range (pizzeria[u][2], 0, -1):
        if (i == pizzeria[u][2]):
            if  (pizzeria[u][2] + pizzeria[u][0] - 1>= 0 and  pizzeria[u][2] + pizzeria[u][0] -1 <= N -1
            and pizzeria[u][1] >= 0 and pizzeria[u][1] <= N - 1):

                city[pizzeria[u][2] + pizzeria[u][0] - 1][pizzeria[u][1] - 1] += 1

        else:

            for j in range (-i, i +1):

                if  (pizzeria[u][2] + pizzeria[u][0] - i >= 1 and pizzeria[u][2] + pizzeria[u][0] - i <= N 
                    and pizzeria[u][1] + j >= 1 and pizzeria[u][1] + j <= N):

                    city[pizzeria [u][2] + pizzeria[u][0] - i - 1][pizzeria[u][1] + j - 1] += 1

#we initiate the max at 0
max = 0

for i in range (0,N):
    for j in range (0,N):
        if (max < city [i][j]):
            max = city [i][j]

max= int(max)
print(max)

